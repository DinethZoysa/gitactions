package com.mfahmi.mymedicineplantidentification.domain.models

data class Plants(val name: String, val imgSrc: String)