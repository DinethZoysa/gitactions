package com.mfahmi.mymedicineplantidentification.domain.models

data class PlantFirebaseModel(var description: String = "")
