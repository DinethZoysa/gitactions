package com.mfahmi.mymedicineplantidentification.data.source.remote.response

import com.google.gson.annotations.SerializedName

data class PlantPictResponse(
    @SerializedName("webformatURL")
    val pictUrl: String
)
